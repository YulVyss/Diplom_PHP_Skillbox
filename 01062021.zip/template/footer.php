<footer class="page-footer">
  <div class="container">
    <a class="page-footer__logo" href="/php_diplom/">
      <img src="/php_diplom/img/logo--footer.svg" alt="Fashion">
    </a>
    <nav class="page-footer__menu">
      <ul class="main-menu main-menu--footer">
        <li>
          <a class="main-menu__item" href="/php_diplom/">Главная</a>
        </li>
        <li>
          <a class="main-menu__item" href="/php_diplom/new.php">Новинки</a>
        </li>
        <li>
          <a class="main-menu__item" href="/php_diplom/sale.php">Sale</a>
        </li>
        <li>
          <a class="main-menu__item" href="/php_diplom/delivery.php">Доставка</a>
        </li>
      </ul>
    </nav>
    <address class="page-footer__copyright">
      © Все права защищены
    </address>
  </div>
</footer>
</body>