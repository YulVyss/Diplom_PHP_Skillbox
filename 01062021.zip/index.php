<?php include $_SERVER['DOCUMENT_ROOT'] . '/php_diplom/template/header.php'; ?>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php_diplom/template/aside.php'; ?>
<?php
$page = 1;
if(isset($_GET['sale']) || isset($_GET['new'])){
  
  $req = "SELECT * from products where ";
    if(isset($_GET['sale'])){
      $req .= 'sale=1';
    }

    if(isset($_GET['new'])){
      $req .= 'new=1';
    }    
    $req .= " LIMIT $num OFFSET $start";
      
    $products = getFilterCategoryProducts($connect, $req);
    
} else {
  $products = getAllProducts($connect, $num, $start);
} 

if(isset($_GET['page'])){
  $page = $_GET['page'];
  $start = ($page * $num) - $num;
  $products = getAllProducts($connect, $num, $start);
} 
// $res = mysqli_query($connect, "SELECT COUNT(*) FROM products");
// $row = mysqli_fetch_assoc($res);
// $total = $row["COUNT(*)"];
$total = getCounter($page, $connect);
$str_pag = ceil($total / $num);





?>
    <section class="shop__list">
      <?php 
        if($products){
          
          showProducts($products);
        }         
      ?>
    </section>
      <ul class="shop__paginator paginator">
      <?php
        for ($i = 1; $i <= $str_pag; $i++){
          echo "<li><a class='paginator__item' href=?page=".$i.">".$i." </a></li>";
        }
      ?>
        <!-- <li>
          <a class="paginator__item">1</a>
        </li>
        <li>
          <a class="paginator__item" href="2">2</a>
        </li> -->
      </ul>
    </div>
  </section>
  <?php include $_SERVER['DOCUMENT_ROOT'] . '/php_diplom/template/order.php'; ?>
</main>
</html>
<?php include $_SERVER['DOCUMENT_ROOT'] . '/php_diplom/template/footer.php'; ?>
