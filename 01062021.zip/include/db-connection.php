<?php 

// if (isset($_POST) && !empty($_POST['submit'])) {
//    $filterSection = $_GET;
//    $new = $_POST['new'] ?? '0';
//    $sale = $_POST['sale'] ?? '';
//    if ($new) {
//        getNewProducts($connect);
//    } else if($sale) {
//     getSaleProducts($connect);
//    } 
// }
